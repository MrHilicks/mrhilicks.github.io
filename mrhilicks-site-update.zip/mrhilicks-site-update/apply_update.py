#!/usr/bin/env python3
"""Обновление существующего сайта с резервной копией и проверкой сборки."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda: file.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def checked_path(root: Path, relative: str) -> Path:
    """Не допускаем выхода за корень проекта или записи в .git."""
    part = Path(relative)
    if part.is_absolute() or '..' in part.parts or '.git' in part.parts:
        raise ValueError(f'Недопустимый путь: {relative}')
    path = root / part
    if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError(f'Обнаружена небезопасная ссылка: {relative}')
    return path


def atomic_copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.mrhilicks-update-', dir=target.parent)
    os.close(fd)
    temp = Path(temporary)
    try:
        shutil.copy2(source, temp)
        os.replace(temp, target)
    finally:
        temp.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', type=Path, default=Path.cwd(), help='Корень существующего репозитория')
    parser.add_argument('--dry-run', action='store_true', help='Проверить архив, не изменяя проект')
    args = parser.parse_args()
    target = args.target.expanduser().resolve()
    try:
        if sys.version_info < (3, 10):
            raise ValueError('Нужен Python 3.10 или новее.')
        for relative in ('scripts/build.py', 'content/site.json', 'templates/home.html'):
            if not (target / relative).is_file():
                raise ValueError(f'Это не корень предыдущей версии сайта: нет {relative}. Перейдите в корень репозитория.')
        if (HERE / 'payload').resolve().is_relative_to(target):
            raise ValueError('Распакуйте обновление во временную папку вне репозитория, как указано в инструкции.')
        manifest = json.loads((HERE / 'update_manifest.json').read_text(encoding='utf-8'))
        records = []
        seen = set()
        for item in manifest['files']:
            relative = item['path']
            if relative in seen:
                raise ValueError(f'Повторный путь в архиве: {relative}')
            seen.add(relative)
            source = checked_path(HERE / 'payload', relative)
            destination = checked_path(target, relative)
            if not source.is_file() or digest(source) != item['sha256']:
                raise ValueError(f'Файл обновления повреждён: {relative}')
            if destination.exists() and not destination.is_file():
                raise ValueError(f'Вместо файла найдена папка: {relative}')
            current = digest(destination) if destination.exists() else None
            if current == item['sha256']:
                continue
            records.append({**item, 'existed': destination.exists(), 'previous_sha256': current})
        print(f'Проект: {target}', flush=True)
        print(f'Версия обновления: {manifest["version"]}. Файлов к установке: {len(records)}.', flush=True)
        changed = [r['path'] for r in records if r['previous_sha256'] is not None and r['previous_sha256'] != r.get('baseline_sha256')]
        if changed:
            print('Есть отличия от исходного архива; текущие варианты будут сохранены в резервной копии:', flush=True)
            for path in changed:
                print('  ' + path, flush=True)
        if args.dry_run:
            print('Проверка завершена. Файлы не изменены.', flush=True)
            return 0
        if not records:
            print('Все файлы обновления уже установлены. Изменений нет.', flush=True)
            return 0
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
        backup = Path.home() / 'mrhilicks-site-backups' / target.name / stamp
        backup.mkdir(parents=True, exist_ok=False)
        # Сначала полностью сохраняем прежние файлы, только затем начинаем замену.
        for item in records:
            if item['existed']:
                atomic_copy(target / item['path'], backup / 'files' / item['path'])
        log = {'version': manifest['version'], 'target': str(target), 'files': records, 'status': 'backup_ready'}
        (backup / 'backup_manifest.json').write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f'Резервная копия: {backup}', flush=True)
        installed = []
        try:
            for item in records:
                atomic_copy(HERE / 'payload' / item['path'], target / item['path'])
                installed.append(item)
            print('Проверка сборки и ссылок...', flush=True)
            subprocess.run([sys.executable, str(target / 'scripts/check.py')], cwd=target, check=True)
        except BaseException:
            print('Проверка не завершилась успешно. Восстанавливаю предыдущие исходники...', flush=True)
            for item in reversed(installed):
                destination = target / item['path']
                if item['existed']:
                    atomic_copy(backup / 'files' / item['path'], destination)
                else:
                    destination.unlink(missing_ok=True)
            log['status'] = 'rolled_back'
            (backup / 'backup_manifest.json').write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding='utf-8')
            subprocess.run([sys.executable, str(target / 'scripts/build.py')], cwd=target, check=False)
            raise
        log['status'] = 'installed'
        (backup / 'backup_manifest.json').write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding='utf-8')
        print('\nОбновление установлено. Git и настройки публикации не изменялись.', flush=True)
        print('Запуск превью: python3 scripts/dev.py', flush=True)
        return 0
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as exc:
        print(f'Ошибка обновления: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())